﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBettingTracker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnNetWinLoss = New Button()
        btnHistory = New Button()
        lblHeading = New Label()
        btnCreateFantasy = New Button()
        btnExit = New Button()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnNetWinLoss
        ' 
        btnNetWinLoss.BackColor = Color.Green
        btnNetWinLoss.Font = New Font("Cooper Black", 14.25F)
        btnNetWinLoss.ForeColor = SystemColors.ControlLightLight
        btnNetWinLoss.Location = New Point(371, 122)
        btnNetWinLoss.Name = "btnNetWinLoss"
        btnNetWinLoss.Size = New Size(166, 68)
        btnNetWinLoss.TabIndex = 1
        btnNetWinLoss.Text = "Net Profit"
        btnNetWinLoss.UseVisualStyleBackColor = False
        ' 
        ' btnHistory
        ' 
        btnHistory.BackColor = Color.Green
        btnHistory.Font = New Font("Cooper Black", 14.25F)
        btnHistory.ForeColor = SystemColors.ControlLightLight
        btnHistory.Location = New Point(607, 122)
        btnHistory.Name = "btnHistory"
        btnHistory.Size = New Size(158, 68)
        btnHistory.TabIndex = 7
        btnHistory.Text = "Betting History"
        btnHistory.UseVisualStyleBackColor = False
        ' 
        ' lblHeading
        ' 
        lblHeading.AutoSize = True
        lblHeading.Font = New Font("Elephant", 23.9999962F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblHeading.Location = New Point(342, 32)
        lblHeading.Name = "lblHeading"
        lblHeading.Size = New Size(225, 41)
        lblHeading.TabIndex = 8
        lblHeading.Text = "Bet Tracker"
        ' 
        ' btnCreateFantasy
        ' 
        btnCreateFantasy.BackColor = Color.Green
        btnCreateFantasy.Font = New Font("Cooper Black", 14.25F)
        btnCreateFantasy.ForeColor = SystemColors.ControlLightLight
        btnCreateFantasy.Location = New Point(158, 122)
        btnCreateFantasy.Name = "btnCreateFantasy"
        btnCreateFantasy.Size = New Size(161, 68)
        btnCreateFantasy.TabIndex = 7
        btnCreateFantasy.Text = "Create Fantasy Pick"
        btnCreateFantasy.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Green
        btnExit.Font = New Font("Cooper Black", 14.25F)
        btnExit.ForeColor = SystemColors.ControlLightLight
        btnExit.Location = New Point(371, 256)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(166, 69)
        btnExit.TabIndex = 9
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.prizePicks
        PictureBox1.Location = New Point(156, 384)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(117, 120)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 10
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.UnderDog
        PictureBox2.Location = New Point(318, 384)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(116, 120)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 11
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = My.Resources.Resources.sleeper
        PictureBox3.Location = New Point(476, 384)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(121, 120)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 12
        PictureBox3.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = My.Resources.Resources.betr
        PictureBox4.Location = New Point(636, 384)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(116, 120)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 13
        PictureBox4.TabStop = False
        ' 
        ' frmBettingTracker
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.PaleGreen
        ClientSize = New Size(913, 585)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(btnExit)
        Controls.Add(btnCreateFantasy)
        Controls.Add(lblHeading)
        Controls.Add(btnHistory)
        Controls.Add(btnNetWinLoss)
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmBettingTracker"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Betting Tracker"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btnNetWinLoss As Button
    Friend WithEvents btnHistory As Button
    Friend WithEvents lblHeading As Label
    Friend WithEvents btnCreateFantasy As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox

End Class
