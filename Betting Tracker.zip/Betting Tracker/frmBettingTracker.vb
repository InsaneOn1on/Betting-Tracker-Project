﻿Imports System.IO
Imports System.Text
Imports System.Windows.Forms.AxHost
' Alexander Kendall
' Betting Tracker Windows Form App
' This class handles the displaying of data to forms based on buttonm presses
Public Class frmBettingTracker
    Private Sub btnCreateFantasy_Click(sender As Object, e As EventArgs) Handles btnCreateFantasy.Click
        Me.Hide()
        frmCreateBet.ShowDialog()
    End Sub
    Private Sub btnHistory_Click(sender As Object, e As EventArgs) Handles btnHistory.Click
        Me.Hide()
        frmHistory.Show()
    End Sub

    Private Sub btnNetWinLoss_Click(sender As Object, e As EventArgs) Handles btnNetWinLoss.Click
        frmNetProfit.Show()
        Me.Hide()

    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
