﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCreateBet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        pnlFantasyPlayers = New Panel()
        btnSubmitPicks = New Button()
        lblStat = New Label()
        Label14 = New Label()
        Label12 = New Label()
        lblPlayerName = New Label()
        cboxResultOU8 = New ComboBox()
        cboxUserOU6 = New ComboBox()
        cboxUserOU4 = New ComboBox()
        cboxUserOU5 = New ComboBox()
        cboxResultOU1 = New ComboBox()
        cboxResultOU2 = New ComboBox()
        cboxUserOU3 = New ComboBox()
        cboxResultOU3 = New ComboBox()
        cboxResultOU4 = New ComboBox()
        cboxResultOU5 = New ComboBox()
        cboxResultOU6 = New ComboBox()
        cboxResultOU7 = New ComboBox()
        cboxUserOU7 = New ComboBox()
        cboxUserOU8 = New ComboBox()
        cboxUserOU2 = New ComboBox()
        cboxUserOU1 = New ComboBox()
        txtName7 = New TextBox()
        txtStat7 = New TextBox()
        txtName8 = New TextBox()
        txtStat8 = New TextBox()
        txtStat3 = New TextBox()
        txtStat4 = New TextBox()
        txtStat5 = New TextBox()
        txtStat6 = New TextBox()
        txtName5 = New TextBox()
        txtName4 = New TextBox()
        txtStat2 = New TextBox()
        txtName2 = New TextBox()
        txtName6 = New TextBox()
        txtName3 = New TextBox()
        txtStat1 = New TextBox()
        txtName1 = New TextBox()
        pnlFantasyParams = New Panel()
        btnSubFantParm = New Button()
        txtAmount = New TextBox()
        lblLegs = New Label()
        lblMulti = New Label()
        lblCash = New Label()
        txtMulti = New TextBox()
        txtLegs = New TextBox()
        btnBack = New Button()
        pnlFantasyPlayers.SuspendLayout()
        pnlFantasyParams.SuspendLayout()
        SuspendLayout()
        ' 
        ' pnlFantasyPlayers
        ' 
        pnlFantasyPlayers.Controls.Add(btnSubmitPicks)
        pnlFantasyPlayers.Controls.Add(lblStat)
        pnlFantasyPlayers.Controls.Add(Label14)
        pnlFantasyPlayers.Controls.Add(Label12)
        pnlFantasyPlayers.Controls.Add(lblPlayerName)
        pnlFantasyPlayers.Controls.Add(cboxResultOU8)
        pnlFantasyPlayers.Controls.Add(cboxUserOU6)
        pnlFantasyPlayers.Controls.Add(cboxUserOU4)
        pnlFantasyPlayers.Controls.Add(cboxUserOU5)
        pnlFantasyPlayers.Controls.Add(cboxResultOU1)
        pnlFantasyPlayers.Controls.Add(cboxResultOU2)
        pnlFantasyPlayers.Controls.Add(cboxUserOU3)
        pnlFantasyPlayers.Controls.Add(cboxResultOU3)
        pnlFantasyPlayers.Controls.Add(cboxResultOU4)
        pnlFantasyPlayers.Controls.Add(cboxResultOU5)
        pnlFantasyPlayers.Controls.Add(cboxResultOU6)
        pnlFantasyPlayers.Controls.Add(cboxResultOU7)
        pnlFantasyPlayers.Controls.Add(cboxUserOU7)
        pnlFantasyPlayers.Controls.Add(cboxUserOU8)
        pnlFantasyPlayers.Controls.Add(cboxUserOU2)
        pnlFantasyPlayers.Controls.Add(cboxUserOU1)
        pnlFantasyPlayers.Controls.Add(txtName7)
        pnlFantasyPlayers.Controls.Add(txtStat7)
        pnlFantasyPlayers.Controls.Add(txtName8)
        pnlFantasyPlayers.Controls.Add(txtStat8)
        pnlFantasyPlayers.Controls.Add(txtStat3)
        pnlFantasyPlayers.Controls.Add(txtStat4)
        pnlFantasyPlayers.Controls.Add(txtStat5)
        pnlFantasyPlayers.Controls.Add(txtStat6)
        pnlFantasyPlayers.Controls.Add(txtName5)
        pnlFantasyPlayers.Controls.Add(txtName4)
        pnlFantasyPlayers.Controls.Add(txtStat2)
        pnlFantasyPlayers.Controls.Add(txtName2)
        pnlFantasyPlayers.Controls.Add(txtName6)
        pnlFantasyPlayers.Controls.Add(txtName3)
        pnlFantasyPlayers.Controls.Add(txtStat1)
        pnlFantasyPlayers.Controls.Add(txtName1)
        pnlFantasyPlayers.Location = New Point(92, 41)
        pnlFantasyPlayers.Name = "pnlFantasyPlayers"
        pnlFantasyPlayers.Size = New Size(727, 397)
        pnlFantasyPlayers.TabIndex = 15
        pnlFantasyPlayers.Visible = False
        ' 
        ' btnSubmitPicks
        ' 
        btnSubmitPicks.BackColor = Color.Green
        btnSubmitPicks.Font = New Font("Cooper Black", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnSubmitPicks.Location = New Point(321, 336)
        btnSubmitPicks.Name = "btnSubmitPicks"
        btnSubmitPicks.Size = New Size(92, 47)
        btnSubmitPicks.TabIndex = 119
        btnSubmitPicks.Text = "Submit"
        btnSubmitPicks.UseVisualStyleBackColor = False
        ' 
        ' lblStat
        ' 
        lblStat.AutoSize = True
        lblStat.Font = New Font("Comic Sans MS", 11.25F)
        lblStat.Location = New Point(286, 21)
        lblStat.Name = "lblStat"
        lblStat.Size = New Size(118, 20)
        lblStat.TabIndex = 98
        lblStat.Text = "Player Statistic"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Comic Sans MS", 11.25F)
        Label14.Location = New Point(501, 21)
        Label14.Name = "Label14"
        Label14.Size = New Size(75, 20)
        Label14.TabIndex = 118
        Label14.Text = "Your Pick"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Comic Sans MS", 11.25F)
        Label12.Location = New Point(604, 21)
        Label12.Name = "Label12"
        Label12.Size = New Size(85, 20)
        Label12.TabIndex = 117
        Label12.Text = "Pick Result"
        ' 
        ' lblPlayerName
        ' 
        lblPlayerName.AutoSize = True
        lblPlayerName.Font = New Font("Comic Sans MS", 11.25F)
        lblPlayerName.Location = New Point(77, 21)
        lblPlayerName.Name = "lblPlayerName"
        lblPlayerName.Size = New Size(120, 20)
        lblPlayerName.TabIndex = 116
        lblPlayerName.Text = "Player FullName"
        ' 
        ' cboxResultOU8
        ' 
        cboxResultOU8.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU8.Font = New Font("Comic Sans MS", 11.25F)
        cboxResultOU8.FormattingEnabled = True
        cboxResultOU8.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU8.Location = New Point(604, 288)
        cboxResultOU8.Name = "cboxResultOU8"
        cboxResultOU8.Size = New Size(85, 28)
        cboxResultOU8.TabIndex = 115
        cboxResultOU8.Visible = False
        ' 
        ' cboxUserOU6
        ' 
        cboxUserOU6.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU6.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU6.FormattingEnabled = True
        cboxUserOU6.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU6.Location = New Point(491, 220)
        cboxUserOU6.Name = "cboxUserOU6"
        cboxUserOU6.Size = New Size(85, 28)
        cboxUserOU6.TabIndex = 114
        cboxUserOU6.Visible = False
        ' 
        ' cboxUserOU4
        ' 
        cboxUserOU4.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU4.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU4.FormattingEnabled = True
        cboxUserOU4.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU4.Location = New Point(491, 152)
        cboxUserOU4.Name = "cboxUserOU4"
        cboxUserOU4.Size = New Size(85, 28)
        cboxUserOU4.TabIndex = 113
        cboxUserOU4.Visible = False
        ' 
        ' cboxUserOU5
        ' 
        cboxUserOU5.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU5.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU5.FormattingEnabled = True
        cboxUserOU5.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU5.Location = New Point(491, 186)
        cboxUserOU5.Name = "cboxUserOU5"
        cboxUserOU5.Size = New Size(85, 28)
        cboxUserOU5.TabIndex = 112
        cboxUserOU5.Visible = False
        ' 
        ' cboxResultOU1
        ' 
        cboxResultOU1.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU1.Font = New Font("Comic Sans MS", 11.25F)
        cboxResultOU1.FormattingEnabled = True
        cboxResultOU1.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU1.Location = New Point(604, 50)
        cboxResultOU1.Name = "cboxResultOU1"
        cboxResultOU1.Size = New Size(85, 28)
        cboxResultOU1.TabIndex = 111
        cboxResultOU1.Visible = False
        ' 
        ' cboxResultOU2
        ' 
        cboxResultOU2.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU2.Font = New Font("Comic Sans MS", 11.25F)
        cboxResultOU2.FormattingEnabled = True
        cboxResultOU2.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU2.Location = New Point(604, 84)
        cboxResultOU2.Name = "cboxResultOU2"
        cboxResultOU2.Size = New Size(85, 28)
        cboxResultOU2.TabIndex = 110
        cboxResultOU2.Visible = False
        ' 
        ' cboxUserOU3
        ' 
        cboxUserOU3.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU3.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU3.FormattingEnabled = True
        cboxUserOU3.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU3.Location = New Point(491, 118)
        cboxUserOU3.Name = "cboxUserOU3"
        cboxUserOU3.Size = New Size(85, 28)
        cboxUserOU3.TabIndex = 109
        cboxUserOU3.Visible = False
        ' 
        ' cboxResultOU3
        ' 
        cboxResultOU3.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU3.Font = New Font("Comic Sans MS", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cboxResultOU3.FormattingEnabled = True
        cboxResultOU3.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU3.Location = New Point(604, 118)
        cboxResultOU3.Name = "cboxResultOU3"
        cboxResultOU3.Size = New Size(85, 28)
        cboxResultOU3.TabIndex = 108
        cboxResultOU3.Visible = False
        ' 
        ' cboxResultOU4
        ' 
        cboxResultOU4.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU4.Font = New Font("Comic Sans MS", 11.25F)
        cboxResultOU4.FormattingEnabled = True
        cboxResultOU4.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU4.Location = New Point(604, 152)
        cboxResultOU4.Name = "cboxResultOU4"
        cboxResultOU4.Size = New Size(85, 28)
        cboxResultOU4.TabIndex = 107
        cboxResultOU4.Visible = False
        ' 
        ' cboxResultOU5
        ' 
        cboxResultOU5.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU5.Font = New Font("Comic Sans MS", 11.25F)
        cboxResultOU5.FormattingEnabled = True
        cboxResultOU5.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU5.Location = New Point(604, 186)
        cboxResultOU5.Name = "cboxResultOU5"
        cboxResultOU5.Size = New Size(85, 28)
        cboxResultOU5.TabIndex = 106
        cboxResultOU5.Visible = False
        ' 
        ' cboxResultOU6
        ' 
        cboxResultOU6.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU6.Font = New Font("Comic Sans MS", 11.25F)
        cboxResultOU6.FormattingEnabled = True
        cboxResultOU6.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU6.Location = New Point(604, 220)
        cboxResultOU6.Name = "cboxResultOU6"
        cboxResultOU6.Size = New Size(85, 28)
        cboxResultOU6.TabIndex = 105
        cboxResultOU6.Visible = False
        ' 
        ' cboxResultOU7
        ' 
        cboxResultOU7.DropDownStyle = ComboBoxStyle.DropDownList
        cboxResultOU7.Font = New Font("Comic Sans MS", 11.25F)
        cboxResultOU7.FormattingEnabled = True
        cboxResultOU7.Items.AddRange(New Object() {"Over", "Under"})
        cboxResultOU7.Location = New Point(604, 254)
        cboxResultOU7.Name = "cboxResultOU7"
        cboxResultOU7.Size = New Size(85, 28)
        cboxResultOU7.TabIndex = 104
        cboxResultOU7.Visible = False
        ' 
        ' cboxUserOU7
        ' 
        cboxUserOU7.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU7.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU7.FormattingEnabled = True
        cboxUserOU7.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU7.Location = New Point(491, 254)
        cboxUserOU7.Name = "cboxUserOU7"
        cboxUserOU7.Size = New Size(85, 28)
        cboxUserOU7.TabIndex = 103
        cboxUserOU7.Visible = False
        ' 
        ' cboxUserOU8
        ' 
        cboxUserOU8.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU8.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU8.FormattingEnabled = True
        cboxUserOU8.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU8.Location = New Point(491, 288)
        cboxUserOU8.Name = "cboxUserOU8"
        cboxUserOU8.Size = New Size(85, 28)
        cboxUserOU8.TabIndex = 102
        cboxUserOU8.Visible = False
        ' 
        ' cboxUserOU2
        ' 
        cboxUserOU2.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU2.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU2.FormattingEnabled = True
        cboxUserOU2.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU2.Location = New Point(491, 84)
        cboxUserOU2.Name = "cboxUserOU2"
        cboxUserOU2.Size = New Size(85, 28)
        cboxUserOU2.TabIndex = 101
        cboxUserOU2.Visible = False
        ' 
        ' cboxUserOU1
        ' 
        cboxUserOU1.DropDownStyle = ComboBoxStyle.DropDownList
        cboxUserOU1.Font = New Font("Comic Sans MS", 11.25F)
        cboxUserOU1.FormattingEnabled = True
        cboxUserOU1.Items.AddRange(New Object() {"Over", "Under"})
        cboxUserOU1.Location = New Point(491, 50)
        cboxUserOU1.Name = "cboxUserOU1"
        cboxUserOU1.Size = New Size(85, 28)
        cboxUserOU1.TabIndex = 100
        cboxUserOU1.Visible = False
        ' 
        ' txtName7
        ' 
        txtName7.Font = New Font("Comic Sans MS", 11.25F)
        txtName7.Location = New Point(39, 254)
        txtName7.Name = "txtName7"
        txtName7.Size = New Size(192, 28)
        txtName7.TabIndex = 99
        txtName7.Visible = False
        ' 
        ' txtStat7
        ' 
        txtStat7.Font = New Font("Comic Sans MS", 11.25F)
        txtStat7.Location = New Point(257, 254)
        txtStat7.Name = "txtStat7"
        txtStat7.Size = New Size(183, 28)
        txtStat7.TabIndex = 97
        txtStat7.Visible = False
        ' 
        ' txtName8
        ' 
        txtName8.Font = New Font("Comic Sans MS", 11.25F)
        txtName8.Location = New Point(39, 288)
        txtName8.Name = "txtName8"
        txtName8.Size = New Size(192, 28)
        txtName8.TabIndex = 96
        txtName8.Visible = False
        ' 
        ' txtStat8
        ' 
        txtStat8.Font = New Font("Comic Sans MS", 11.25F)
        txtStat8.Location = New Point(257, 288)
        txtStat8.Name = "txtStat8"
        txtStat8.Size = New Size(183, 28)
        txtStat8.TabIndex = 95
        txtStat8.Visible = False
        ' 
        ' txtStat3
        ' 
        txtStat3.Font = New Font("Comic Sans MS", 11.25F)
        txtStat3.Location = New Point(257, 118)
        txtStat3.Name = "txtStat3"
        txtStat3.Size = New Size(183, 28)
        txtStat3.TabIndex = 94
        txtStat3.Visible = False
        ' 
        ' txtStat4
        ' 
        txtStat4.Font = New Font("Comic Sans MS", 11.25F)
        txtStat4.Location = New Point(257, 152)
        txtStat4.Name = "txtStat4"
        txtStat4.Size = New Size(183, 28)
        txtStat4.TabIndex = 93
        txtStat4.Visible = False
        ' 
        ' txtStat5
        ' 
        txtStat5.Font = New Font("Comic Sans MS", 11.25F)
        txtStat5.Location = New Point(257, 186)
        txtStat5.Name = "txtStat5"
        txtStat5.Size = New Size(183, 28)
        txtStat5.TabIndex = 92
        txtStat5.Visible = False
        ' 
        ' txtStat6
        ' 
        txtStat6.Font = New Font("Comic Sans MS", 11.25F)
        txtStat6.Location = New Point(257, 220)
        txtStat6.Name = "txtStat6"
        txtStat6.Size = New Size(183, 28)
        txtStat6.TabIndex = 91
        txtStat6.Visible = False
        ' 
        ' txtName5
        ' 
        txtName5.Font = New Font("Comic Sans MS", 11.25F)
        txtName5.Location = New Point(39, 186)
        txtName5.Name = "txtName5"
        txtName5.Size = New Size(192, 28)
        txtName5.TabIndex = 90
        txtName5.Visible = False
        ' 
        ' txtName4
        ' 
        txtName4.Font = New Font("Comic Sans MS", 11.25F)
        txtName4.Location = New Point(39, 152)
        txtName4.Name = "txtName4"
        txtName4.Size = New Size(192, 28)
        txtName4.TabIndex = 89
        txtName4.Visible = False
        ' 
        ' txtStat2
        ' 
        txtStat2.Font = New Font("Comic Sans MS", 11.25F)
        txtStat2.Location = New Point(257, 84)
        txtStat2.Name = "txtStat2"
        txtStat2.Size = New Size(183, 28)
        txtStat2.TabIndex = 88
        txtStat2.Visible = False
        ' 
        ' txtName2
        ' 
        txtName2.Font = New Font("Comic Sans MS", 11.25F)
        txtName2.Location = New Point(39, 84)
        txtName2.Name = "txtName2"
        txtName2.Size = New Size(192, 28)
        txtName2.TabIndex = 87
        txtName2.Visible = False
        ' 
        ' txtName6
        ' 
        txtName6.Font = New Font("Comic Sans MS", 11.25F)
        txtName6.Location = New Point(39, 220)
        txtName6.Name = "txtName6"
        txtName6.Size = New Size(192, 28)
        txtName6.TabIndex = 86
        txtName6.Visible = False
        ' 
        ' txtName3
        ' 
        txtName3.Font = New Font("Comic Sans MS", 11.25F)
        txtName3.Location = New Point(39, 118)
        txtName3.Name = "txtName3"
        txtName3.Size = New Size(192, 28)
        txtName3.TabIndex = 85
        txtName3.Visible = False
        ' 
        ' txtStat1
        ' 
        txtStat1.Font = New Font("Comic Sans MS", 11.25F)
        txtStat1.Location = New Point(257, 50)
        txtStat1.Name = "txtStat1"
        txtStat1.Size = New Size(183, 28)
        txtStat1.TabIndex = 84
        txtStat1.Visible = False
        ' 
        ' txtName1
        ' 
        txtName1.Font = New Font("Comic Sans MS", 11.25F)
        txtName1.Location = New Point(39, 50)
        txtName1.Name = "txtName1"
        txtName1.Size = New Size(192, 28)
        txtName1.TabIndex = 83
        txtName1.Visible = False
        ' 
        ' pnlFantasyParams
        ' 
        pnlFantasyParams.Controls.Add(btnSubFantParm)
        pnlFantasyParams.Controls.Add(txtAmount)
        pnlFantasyParams.Controls.Add(lblLegs)
        pnlFantasyParams.Controls.Add(lblMulti)
        pnlFantasyParams.Controls.Add(lblCash)
        pnlFantasyParams.Controls.Add(txtMulti)
        pnlFantasyParams.Controls.Add(txtLegs)
        pnlFantasyParams.Location = New Point(216, 41)
        pnlFantasyParams.Name = "pnlFantasyParams"
        pnlFantasyParams.Size = New Size(475, 222)
        pnlFantasyParams.TabIndex = 14
        ' 
        ' btnSubFantParm
        ' 
        btnSubFantParm.BackColor = Color.Green
        btnSubFantParm.Font = New Font("Cooper Black", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnSubFantParm.Location = New Point(185, 155)
        btnSubFantParm.Name = "btnSubFantParm"
        btnSubFantParm.Size = New Size(122, 48)
        btnSubFantParm.TabIndex = 12
        btnSubFantParm.Text = "Submit"
        btnSubFantParm.UseVisualStyleBackColor = False
        ' 
        ' txtAmount
        ' 
        txtAmount.Font = New Font("Comic Sans MS", 11.25F)
        txtAmount.Location = New Point(286, 90)
        txtAmount.Name = "txtAmount"
        txtAmount.Size = New Size(100, 28)
        txtAmount.TabIndex = 2
        ' 
        ' lblLegs
        ' 
        lblLegs.AutoSize = True
        lblLegs.Font = New Font("Comic Sans MS", 11.25F)
        lblLegs.Location = New Point(64, 25)
        lblLegs.Name = "lblLegs"
        lblLegs.Size = New Size(159, 20)
        lblLegs.TabIndex = 9
        lblLegs.Text = "Number of Legs (2-8)"
        ' 
        ' lblMulti
        ' 
        lblMulti.AutoSize = True
        lblMulti.Font = New Font("Comic Sans MS", 11.25F)
        lblMulti.Location = New Point(93, 59)
        lblMulti.Name = "lblMulti"
        lblMulti.Size = New Size(76, 20)
        lblMulti.TabIndex = 10
        lblMulti.Text = "Multiplier"
        ' 
        ' lblCash
        ' 
        lblCash.AutoSize = True
        lblCash.Font = New Font("Comic Sans MS", 11.25F)
        lblCash.Location = New Point(93, 93)
        lblCash.Name = "lblCash"
        lblCash.Size = New Size(105, 20)
        lblCash.TabIndex = 11
        lblCash.Text = "Entry Amount"
        ' 
        ' txtMulti
        ' 
        txtMulti.Font = New Font("Comic Sans MS", 11.25F)
        txtMulti.Location = New Point(286, 56)
        txtMulti.Name = "txtMulti"
        txtMulti.Size = New Size(100, 28)
        txtMulti.TabIndex = 1
        ' 
        ' txtLegs
        ' 
        txtLegs.Font = New Font("Comic Sans MS", 11.25F)
        txtLegs.Location = New Point(286, 22)
        txtLegs.Name = "txtLegs"
        txtLegs.Size = New Size(100, 28)
        txtLegs.TabIndex = 0
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Green
        btnBack.Font = New Font("Cooper Black", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnBack.Location = New Point(413, 477)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(92, 47)
        btnBack.TabIndex = 120
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' frmCreateBet
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.PaleGreen
        ClientSize = New Size(918, 550)
        Controls.Add(btnBack)
        Controls.Add(pnlFantasyPlayers)
        Controls.Add(pnlFantasyParams)
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmCreateBet"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Bet Creation"
        pnlFantasyPlayers.ResumeLayout(False)
        pnlFantasyPlayers.PerformLayout()
        pnlFantasyParams.ResumeLayout(False)
        pnlFantasyParams.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents pnlFantasyPlayers As Panel
    Friend WithEvents btnSubmitPicks As Button
    Friend WithEvents lblStat As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblPlayerName As Label
    Friend WithEvents cboxResultOU8 As ComboBox
    Friend WithEvents cboxUserOU6 As ComboBox
    Friend WithEvents cboxUserOU4 As ComboBox
    Friend WithEvents cboxUserOU5 As ComboBox
    Friend WithEvents cboxResultOU1 As ComboBox
    Friend WithEvents cboxResultOU2 As ComboBox
    Friend WithEvents cboxUserOU3 As ComboBox
    Friend WithEvents cboxResultOU3 As ComboBox
    Friend WithEvents cboxResultOU4 As ComboBox
    Friend WithEvents cboxResultOU5 As ComboBox
    Friend WithEvents cboxResultOU6 As ComboBox
    Friend WithEvents cboxResultOU7 As ComboBox
    Friend WithEvents cboxUserOU7 As ComboBox
    Friend WithEvents cboxUserOU8 As ComboBox
    Friend WithEvents cboxUserOU2 As ComboBox
    Friend WithEvents cboxUserOU1 As ComboBox
    Friend WithEvents txtName7 As TextBox
    Friend WithEvents txtStat7 As TextBox
    Friend WithEvents txtName8 As TextBox
    Friend WithEvents txtStat8 As TextBox
    Friend WithEvents txtStat3 As TextBox
    Friend WithEvents txtStat4 As TextBox
    Friend WithEvents txtStat5 As TextBox
    Friend WithEvents txtStat6 As TextBox
    Friend WithEvents txtName5 As TextBox
    Friend WithEvents txtName4 As TextBox
    Friend WithEvents txtStat2 As TextBox
    Friend WithEvents txtName2 As TextBox
    Friend WithEvents txtName6 As TextBox
    Friend WithEvents txtName3 As TextBox
    Friend WithEvents txtStat1 As TextBox
    Friend WithEvents txtName1 As TextBox
    Friend WithEvents pnlFantasyParams As Panel
    Friend WithEvents btnSubFantParm As Button
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents lblLegs As Label
    Friend WithEvents lblMulti As Label
    Friend WithEvents lblCash As Label
    Friend WithEvents txtMulti As TextBox
    Friend WithEvents txtLegs As TextBox
    Friend WithEvents btnBack As Button
End Class
