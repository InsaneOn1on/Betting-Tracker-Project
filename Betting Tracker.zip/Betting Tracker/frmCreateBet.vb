﻿Imports System.Diagnostics.Eventing.Reader
Imports System.Drawing.Text
Imports System.IO
' Alexander Kendall
' Betting Tracker Windows Form App
' This class handles all the actions in frmCreateBet that is displayed after a button is pressed in frmBettingTracker

Public Class frmCreateBet
    ' These are the local variables used In this calss
    Dim tempWinnings, tempLoss, decMulti, decAmount, netWinLoss As Decimal
    Dim intLegs As Integer
    Dim winLoss As Boolean
    ' Variable for th folder path that all the bets are stored in
    Private folderPath As String = "Bets"





    ' This sub handles the button clicks from the panel containing number of legs, multiplier, and amount of the entry
    Private Sub btnSubFantParm_Click(sender As Object, e As EventArgs) Handles btnSubFantParm.Click
        ' Creates string variables for user text box entries
        Dim strLegs, strMulti, strAmount As String
        strLegs = txtLegs.Text
        strMulti = txtMulti.Text
        strAmount = txtAmount.Text
        ' This creates 4 arrays holding the text and cobo boxes for each player entry that the user can enter


        ' Input validation for the number of legs, multiplier, and amount text boxes
        ' Sets variables for calculating winnings

        If Integer.TryParse(strLegs, intLegs) And intLegs > 1 And intLegs < 9 And Decimal.TryParse(strMulti, decMulti) And decMulti > 0 And Decimal.TryParse(strAmount, decAmount) And decAmount > 0 Then
            intLegs = intLegs
            decMulti = Math.Round(decMulti, 2)
            decAmount = Math.Round(decAmount, 2)
            tempWinnings = decAmount * decMulti

            pnlFantasyPlayersVisible()

            ' This creates 4 arrays holding the text and combo boxes for each player entry that the user can enter
            Dim txtNames As TextBox() = {txtName1, txtName2, txtName3, txtName4, txtName5, txtName6, txtName7, txtName8}
            Dim txtStats As TextBox() = {txtStat1, txtStat2, txtStat3, txtStat4, txtStat5, txtStat6, txtStat7, txtStat8}
            Dim cboxPredictions As ComboBox() = {cboxUserOU1, cboxUserOU2, cboxUserOU3, cboxUserOU4, cboxUserOU5, cboxUserOU6, cboxUserOU7, cboxUserOU8}
            Dim cboxResults As ComboBox() = {cboxResultOU1, cboxResultOU2, cboxResultOU3, cboxResultOU4, cboxResultOU5, cboxResultOU6, cboxResultOU7, cboxResultOU8}

            ' This for loop set only the amount of boxes needed to be visible
            For i As Integer = 0 To intLegs - 1
                txtNames(i).Visible = True
                txtStats(i).Visible = True
                cboxPredictions(i).Visible = True
                cboxResults(i).Visible = True
            Next

        Else
            ' Shows a message box if the user entry is not a valid one
            MessageBox.Show("Please enter a valid value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            clear()

        End If
    End Sub

    ' Methods to make on panel visible and the other not
    Public Sub pnlFantasyPlayersVisible()
        pnlFantasyParams.Visible = False
        pnlFantasyPlayers.Visible = True
    End Sub
    Public Sub pnlFantasyParamsVisible()
        pnlFantasyParams.Visible = True
        pnlFantasyPlayers.Visible = False
    End Sub

    ' This sub handles the submission of the bet entry names, stats, and results
    ' It places them into a text file that is stored into a folder called bets
    Private Sub btnSubmitPicks_Click(sender As Object, e As EventArgs) Handles btnSubmitPicks.Click

        ' Thse are local variables that are used store the users entrys in arrays and save them into a txt file with a unique id
        Dim uniqueId As String = DateTime.Now.ToString("yyyyMMddHHmmssfff")
        Dim fileName As String = $"data_{uniqueId}.txt"
        Dim filePath As String = Path.Combine(folderPath, fileName)
        ' This creates 4 arrays holding the text and combo boxes for the users entry
        Dim txtNames As TextBox() = {txtName1, txtName2, txtName3, txtName4, txtName5, txtName6, txtName7, txtName8}
        Dim txtStats As TextBox() = {txtStat1, txtStat2, txtStat3, txtStat4, txtStat5, txtStat6, txtStat7, txtStat8}
        Dim cboxPredictions As ComboBox() = {cboxUserOU1, cboxUserOU2, cboxUserOU3, cboxUserOU4, cboxUserOU5, cboxUserOU6, cboxUserOU7, cboxUserOU8}
        Dim cboxResults As ComboBox() = {cboxResultOU1, cboxResultOU2, cboxResultOU3, cboxResultOU4, cboxResultOU5, cboxResultOU6, cboxResultOU7, cboxResultOU8}

        ' For loop to check if the results match the perdictions
        For i As Integer = 0 To txtNames.Length - 1
            If cboxPredictions(i).SelectedItem IsNot cboxResults(i).SelectedItem Then
                winLoss = False
                Exit For
            Else
                winLoss = True
            End If

        Next
        ' If statement to calculate the net win or loss
        If winLoss = False Then
            netWinLoss = netWinLoss - decAmount
        Else
            netWinLoss = (netWinLoss - decAmount) + tempWinnings

        End If

        ' This creates the file and writes the contents from the arrays into the file using a for loop
        Using writer As New StreamWriter(filePath, True)
            For i As Integer = 1 To intLegs
                writer.WriteLine($"Leg {i}:")
                writer.WriteLine($"Name: {txtNames(i - 1).Text}")
                writer.WriteLine($"Statistics: {txtStats(i - 1).Text}")
                writer.WriteLine($"Prediction: {cboxPredictions(i - 1).SelectedItem}")
                writer.WriteLine($"Result: {cboxResults(i - 1).SelectedItem}")
                writer.WriteLine() ' empty line for separation 
            Next
            writer.WriteLine($"Entry Amount: {decAmount.ToString("C")}")

            ' Writes whether the entry won or lost

            If winLoss = True Then
                writer.WriteLine($"Won: {netWinLoss.ToString("C")}")
            Else
                writer.WriteLine($"Lost: {netWinLoss.ToString("C")}")
            End If

        End Using

        ' This if statement is for keeping track of the net Wins by reading from a file and deleting it and replacing it with a new one with a new value
        Dim filePathWinLoss As String = "netWinLoss.txt"
        If File.Exists(filePathWinLoss) Then
            Dim netProfit As Decimal
            Dim lines() As String = File.ReadAllLines(filePathWinLoss)
            netProfit = Convert.ToDecimal(lines(0))
            netProfit = netProfit + netWinLoss
            System.IO.File.Delete("netWinLoss.txt")
            Using writer As New StreamWriter(filePathWinLoss, True)
                writer.WriteLine($"{netProfit}")
            End Using
        Else
            MessageBox.Show("File not found!")
        End If
        '   Resets the net win back to 0 after it is saved
        netWinLoss = 0
        ' Hides the form and shows frmBettingTracker
        Hide()
        frmBettingTracker.Show()
        clear()
        pnlFantasyParamsVisible()
    End Sub

    ' Clears the text box and combo box values

    Public Sub clear()
        txtLegs.Text = Nothing
        txtMulti.Text = Nothing
        txtAmount.Text = Nothing


        ' This creates 4 arrays holding the text and combo boxes to be set to nothing and be invisible
        Dim txtNames As TextBox() = {txtName1, txtName2, txtName3, txtName4, txtName5, txtName6, txtName7, txtName8}
        Dim txtStats As TextBox() = {txtStat1, txtStat2, txtStat3, txtStat4, txtStat5, txtStat6, txtStat7, txtStat8}
        Dim cboxPredictions As ComboBox() = {cboxUserOU1, cboxUserOU2, cboxUserOU3, cboxUserOU4, cboxUserOU5, cboxUserOU6, cboxUserOU7, cboxUserOU8}
        Dim cboxResults As ComboBox() = {cboxResultOU1, cboxResultOU2, cboxResultOU3, cboxResultOU4, cboxResultOU5, cboxResultOU6, cboxResultOU7, cboxResultOU8}


        For i As Integer = 0 To txtNames.Length - 1
            txtNames(i).Visible = False
            txtStats(i).Visible = False
            cboxPredictions(i).Visible = False
            cboxResults(i).Visible = False
            txtNames(i).Text = Nothing
            txtStats(i).Text = Nothing
            cboxResults(i).Text = Nothing
            cboxPredictions(i).Text = Nothing
        Next

    End Sub
    ' This sub is in case the user closes out the form, it displays the frmBettingHistory
    Private Sub frmCreateBet_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        frmBettingTracker.Show()
    End Sub
    ' This sub is a button that closes the form without submitting any values
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Close()
        frmBettingTracker.Show()
        pnlFantasyParams.Visible = True
        pnlFantasyPlayers.Visible = False
        clear()

    End Sub
End Class