﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHistory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtBoxHistory = New RichTextBox()
        btnBack = New Button()
        SuspendLayout()
        ' 
        ' txtBoxHistory
        ' 
        txtBoxHistory.BackColor = Color.PaleGreen
        txtBoxHistory.BorderStyle = BorderStyle.None
        txtBoxHistory.Font = New Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtBoxHistory.ImeMode = ImeMode.NoControl
        txtBoxHistory.Location = New Point(12, 40)
        txtBoxHistory.Name = "txtBoxHistory"
        txtBoxHistory.ReadOnly = True
        txtBoxHistory.Size = New Size(491, 829)
        txtBoxHistory.TabIndex = 17
        txtBoxHistory.Text = ""
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Green
        btnBack.Font = New Font("Cooper Black", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnBack.ForeColor = SystemColors.ControlLightLight
        btnBack.Location = New Point(194, 904)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(102, 52)
        btnBack.TabIndex = 18
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' frmHistory
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.PaleGreen
        ClientSize = New Size(515, 986)
        Controls.Add(btnBack)
        Controls.Add(txtBoxHistory)
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmHistory"
        StartPosition = FormStartPosition.CenterScreen
        Text = "History"
        ResumeLayout(False)
    End Sub
    Friend WithEvents txtBoxHistory As RichTextBox
    Friend WithEvents btnBack As Button
End Class
