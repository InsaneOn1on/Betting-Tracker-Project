﻿Imports System.Formats.Tar
Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
' Alexander Kendall
' Betting Tracker Windows Form App
' This class handles the displaying of data to frmHistoty that is displayed after a button is pressed in frmBettingTracker
Public Class frmHistory
    ' This sub is handled on the form loading
    Private Sub frmHistory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Makes sure that the text box is clear
        txtBoxHistory.Clear()

        ' Creates a string varibale to contain the folder path that the txt files are stored in
        Dim folderPath As String = "Bets"

        ' Checks if the folder exist
        If Directory.Exists(folderPath) Then
            ' Gets all the txt files in the folder and stores them into an array
            Dim txtFiles() As String = Directory.GetFiles(folderPath, "*.txt")

            ' Reads the contents of each txt file and places it into TextBox
            For Each txtFile As String In txtFiles
                Try
                    ' Finds the creation date
                    Dim creationDate As DateTime = File.GetCreationTime(txtFile)
                    'Formats the creation date
                    Dim formattedDate As String = creationDate.ToString("MM/yyyy/dd")
                    ' Reads all the text contents of the file
                    Dim fileContents As String = File.ReadAllText(txtFile)

                    ' Adds the file contents to the TextBox
                    txtBoxHistory.AppendText($"-----{formattedDate}-----{Environment.NewLine} ")
                    txtBoxHistory.AppendText(fileContents & Environment.NewLine & Environment.NewLine)
                Catch ex As Exception
                    ' Handle any errors while reading files 
                    MessageBox.Show($"Error reading file {Path.GetFileName(txtFile)}: {ex.Message}")
                End Try
            Next

            ' Show message if no txt files were found
            If txtFiles.Length = 0 Then
                txtBoxHistory.AppendText($"-----There are no bets yet-----{Environment.NewLine}")
                txtBoxHistory.AppendText($"-----Create a bet and come back.-----")
            End If
        Else
            ' Displays a message box to show there is a problem with files
            MessageBox.Show("There is not folder to hold bets")
        End If
    End Sub
    ' This sub is in case the user closes out the form, it displays the frmBettingHistory
    Private Sub frmHistory_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        frmBettingTracker.Show()
    End Sub
    ' This sub is a button that closes the form
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Close()
        frmBettingTracker.Show()
    End Sub


End Class