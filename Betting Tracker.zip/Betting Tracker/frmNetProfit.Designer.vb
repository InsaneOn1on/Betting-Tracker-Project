﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNetProfit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnBack = New Button()
        txtBoxProfit = New TextBox()
        lblNetHeading = New Label()
        SuspendLayout()
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Green
        btnBack.Font = New Font("Cooper Black", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnBack.ForeColor = SystemColors.ControlLightLight
        btnBack.Location = New Point(251, 270)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(110, 56)
        btnBack.TabIndex = 1
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' txtBoxProfit
        ' 
        txtBoxProfit.BackColor = Color.PaleGreen
        txtBoxProfit.BorderStyle = BorderStyle.None
        txtBoxProfit.Font = New Font("Cooper Black", 24F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtBoxProfit.ForeColor = SystemColors.WindowText
        txtBoxProfit.Location = New Point(251, 156)
        txtBoxProfit.Name = "txtBoxProfit"
        txtBoxProfit.ReadOnly = True
        txtBoxProfit.Size = New Size(110, 37)
        txtBoxProfit.TabIndex = 2
        txtBoxProfit.TextAlign = HorizontalAlignment.Center
        ' 
        ' lblNetHeading
        ' 
        lblNetHeading.AutoSize = True
        lblNetHeading.Font = New Font("Comic Sans MS", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblNetHeading.Location = New Point(228, 85)
        lblNetHeading.Name = "lblNetHeading"
        lblNetHeading.Size = New Size(168, 26)
        lblNetHeading.TabIndex = 3
        lblNetHeading.Text = "Your Net Profit is"
        ' 
        ' frmNetProfit
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.PaleGreen
        ClientSize = New Size(614, 359)
        Controls.Add(lblNetHeading)
        Controls.Add(txtBoxProfit)
        Controls.Add(btnBack)
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmNetProfit"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Net Profit"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btnBack As Button
    Friend WithEvents txtBoxProfit As TextBox
    Friend WithEvents lblNetHeading As Label
End Class
