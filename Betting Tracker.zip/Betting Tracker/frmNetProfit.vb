﻿Imports System.IO
' Alexander Kendall
' Betting Tracker Windows Form App
' This class handles the displaying of data to frmNetProfit that is displayed after a button is pressed in frmBettingTracker
Public Class frmNetProfit
    ' This sub is handled on the form loading
    Private Sub frmNetProfit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtBoxProfit.Clear()

        ' Creates a string varibale to contain the folder path that the txt file is stored in
        Dim folderPath As String = "netWinLoss.txt"

        ' Checks if the folder exists
        If File.Exists(folderPath) Then
            ' Reads all the lines in the txt file and places them into an array
            Dim lines() As String = File.ReadAllLines(folderPath)


            ' Creates a str to read the first line of the file and creates a decimal variable

            Dim strNetProfit As String = lines(0)
            Dim decNetProfit As Decimal
            ' Parses the string to a decimal and sets the color of the variable
            If Decimal.TryParse(strNetProfit, decNetProfit) And decNetProfit < 0 Then
                txtBoxProfit.ForeColor = Color.Red

            Else
                txtBoxProfit.ForeColor = Color.Green
            End If

            ' Displays the decimal value to a text box
            txtBoxProfit.Text = decNetProfit.ToString()


            ' Displays a message box to show there is a problem with files

        Else
            MessageBox.Show("There is not file to hold net profit")
        End If

    End Sub
    ' This sub is in case the user closes out the form, it displays the frmBettingHistory
    Private Sub frmCreateBet_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        frmBettingTracker.Show()
    End Sub
    ' This sub is a button that closes the form
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Close()
        frmBettingTracker.Show()
    End Sub


End Class